//
//  SuggestionPage.swift
//  BasicTimer
//
//  Created by Meghan on 2018-11-06.
//  Copyright © 2018 Practice. All rights reserved.
//

import Foundation
import UIKit

/*
 let locations = ["Submarine", "Pizza Shop", "Castle", "Beach", "Soup Kitchen"]

 let charactertics = ["Drowsy", "Moody", "Hysterical", "Conceited", "Loving", "Motherly"]
let objects = ["Stapler", "Magic 8 Ball"]
 */

 
var category = "location"
var data: Data = Data()

class SuggestionPage: UIViewController {
    
    

    var locations = data.locations
    var charactertics = data.characteristics
    var objects = data.objects
    var theme = data.theme
    @IBOutlet weak var Suggestion: UILabel!
    @IBOutlet weak var GenerateButton: UIButton!
    @IBOutlet weak var CategoryChooser: UISegmentedControl!
    override func viewDidLoad() {
        super.viewDidLoad()
              // Do any additional setup after loading the view.
        
    }
    
    @IBAction func ChooseCategory(_ sender: Any) {
        switch CategoryChooser.selectedSegmentIndex{
        case 0:
            print("Location")
            category="location"
        case 1:
            print("Object")
            category="object"
        case 2:
            print("Characteristic")
            category="characteristic"
        case 3:
            category="theme"
        default:
            break
        }
    }
    
    @IBAction func GenerateSuggestion(_ sender: Any) {
        if (category == "" ) {
            print("choose category")
        }
        if (category == "location") {
            //print(locations.randomElement()!)
            Suggestion.text = locations.randomElement()!
            
        }
        if category == "object"{
            Suggestion.text = objects.randomElement()!
        }
        if category == "characteristic"{
            Suggestion.text = charactertics.randomElement()!
        }
        if category == "theme"{
            Suggestion.text = theme.randomElement()!
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
