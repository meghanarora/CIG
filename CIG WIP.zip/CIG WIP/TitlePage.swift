//
//  TitlePage.swift
//  BasicTimer
//
//  Created by Meghan on 2017-09-14.
//  Copyright © 2017 Practice. All rights reserved.
//

import Foundation
import UIKit

class IntroPage: UIViewController {
    
    
}
