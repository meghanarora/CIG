//
//  TimerPage.swift
//  BasicTimer
//
//  Created by Meghan on 2017-09-09.
//  Copyright © 2017 Practice. All rights reserved.
//

import UIKit
import AVFoundation
//import MongoKitten


class TimerPage: UIViewController {

   
    @IBOutlet weak var TimerLabel: UILabel!
    @IBOutlet weak var StartButton: UIButton!
    
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    
    let systemSoundID: SystemSoundID = 1021
    
    var seconds: Int = 180
    var timer = Timer()
    var isTimerRunning = false
    

    override func viewDidLoad() {
        super.viewDidLoad()    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    @IBAction func StartTimer(_ sender: Any) {
        runTimer()
        AudioServicesPlaySystemSound (systemSoundID)
        let disableSegment = abs(segmentedControl.selectedSegmentIndex - 1)
        print(segmentedControl.selectedSegmentIndex)
        print(disableSegment)
        segmentedControl.setEnabled(false, forSegmentAt: disableSegment)
        StartButton.isEnabled = false
    }
    
    
    @IBAction func PauseTimer(_ sender: Any) {
        isTimerRunning = false
        timer.invalidate()
        StartButton.setTitle("Resume", for: .normal)
        StartButton.isEnabled = true
        
    }
    
    
    
    @IBAction func ResetTimer(_ sender: Any) {
        timer.invalidate()
        StartButton.setTitle("Start", for: .normal)
        seconds = 240
        timer = Timer()
        isTimerRunning = false
        StartButton.isEnabled = true
        if (segmentedControl.selectedSegmentIndex == 0){
            TimerLabel.text = "3:00"
            segmentedControl.setEnabled(true, forSegmentAt: 1)
            
        }
        else if (segmentedControl.selectedSegmentIndex == 1) {
            TimerLabel.text = "4:00"
            segmentedControl.setEnabled(true, forSegmentAt: 0)
        }
        
        else {
            segmentedControl.setEnabled(true, forSegmentAt: 0)
            segmentedControl.setEnabled(true, forSegmentAt: 1)
        }
        
    }
    
    
    @IBAction func changeTime(_ sender: Any) {
        if (isTimerRunning == true) {
            return
        }
        switch segmentedControl.selectedSegmentIndex{
            case 0:
                print("Junior")
                seconds = 180
                TimerLabel.text = "3:00"
            case 1:
                print("Senior")
                seconds = 240
                TimerLabel.text = "4:00"
            case 2:
                print("Test")
                seconds = 65
                TimerLabel.text = "1:05"
            default:
                break
        }
    }
    
    
    func runTimer() {
        print("runTimer")
        isTimerRunning = true
        timer = Timer.scheduledTimer( timeInterval: 1, target: self, selector: (#selector(TimerPage.updateTimer)), userInfo: nil, repeats: true)
    }
    
    func updateTimer() {
        if (seconds == 0) {
            timer.invalidate()
            isTimerRunning = false
            StartButton.setTitle("Start", for: .normal)
            AudioServicesPlaySystemSound (systemSoundID)
        }
        else if seconds > 0 {
            if seconds == 31 {
                AudioServicesPlaySystemSound (systemSoundID)
            }
            if seconds == 61 {
                AudioServicesPlaySystemSound (systemSoundID)
            }
            seconds -= 1
        }
        TimerLabel.text = formatLabel(seconds: seconds)
    }
    
    func formatLabel(seconds: Int) -> String {
        var label = String(seconds/60) + ":"
        if (seconds % 60) < 10 {
            label += "0"
        }
        label += String(seconds % 60)
        print(label)
        return label
    }
    
    @IBAction func toHome(_ sender: Any) {
        performSegue(withIdentifier: "toHome", sender: self)
        timer.invalidate()
    }
    
}

