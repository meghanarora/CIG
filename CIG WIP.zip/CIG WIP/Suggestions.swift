//
//  Suggestions.swift
//  BasicTimer
//
//  Created by Meghan on 2018-11-06.
//  Copyright © 2018 Practice. All rights reserved.
//

import Foundation

public class Data: NSObject {
    let locations = ["Submarine", "Pizza Shop", "Castle", "Beach", "Soup Kitchen","Swamp", "Forest", "Park", "Farm", "Inside The Human Stomach", "A Deserted Island", "Boat", "Bank",  "Volcano", "Middle of the Ocean", "Jungle", "Desert", "Lakeside Resort", "Airport", "Baseball Diamond", "Auto Shop", "Trendy Café", "Cave", "Film Set", "College Dormitory", "Community Center", "Anatomical Lab", "Museum", "Courthouse", "Train", "Bar", "Motel", "Shoebox"]


    
    
    let characteristics = ["Drowsy", "Moody", "Hysterical", "Conceited", "Loving", "Motherly", "Brave", "Reliable", "Kind", "Silly", "Self-centred", "Strange", "Serious", "Light-Hearted", "Fast", "Lucky", "Bully", "Oblivious", "Shy", "Nervous", "Forgetful", "Controlling", "Apathetic"]
    
    
    
    let objects = ["Stapler", "Magic 8 Ball", "Scarf", "Stapler", "Necklace", "Lamp", "Telescope", "Stopwatch", "Juice Box", "Camera", "Cards", "Baseball", "Catching Mitt", "Shopping Cart", "Maple Syrup", "Dental Floss", "Bowl", "Rice", "Axe", "Plow", "Reusable Straw", "Scarecrow", "Candy Bar Wrapper", "Canned Beans", "Shopping cart", "Seltzer", "Trombone", "Mitten", "Extension Cord", "Poster"]
    
    
    
    let theme  = ["Discovery", "Play", "Necklace", "Connection", "Expansion", "Electricity", "Adventure", "Destruction", "Construction", "History", "Mysterious", "Transmission", "Instantaneous", "Fortune", "Competition", "Safety", "Danger", "Light", "Difference", "Dream", "Sequence", "Difficulty", "Growth", "Game", "Sweet", "Hunger", "Memory", "Generation", "Duty", "Justice", "Honesty", "Renovation", "Mimic", "Rebirth"]
                  
}
